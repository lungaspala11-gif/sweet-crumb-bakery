/* =====================================================
   Sweet Crumb Artisan Bakery — script.js
   Student: Lunga Spala (ST10520775) — WEDE5020, Part 1

   Part 1 focuses on HTML structure and content, so the
   mobile navigation menu is handled with a CSS-only
   checkbox toggle (see css/style.css) rather than
   JavaScript. This file is kept in the project's /js
   folder, as required by the file structure, and will be
   built out with interactive functionality (e.g. form
   validation, image gallery/lightbox behaviour) in
   Part 2 and Part 3 of this PoE.
   ===================================================== */

// Reserved for Part 2 / Part 3 functionality.
