# Sweet Crumb Artisan Bakery — Website (WEDE5020 PoE)

## Student Information
- **Student Number:** ST10520775
- **Name:** Lunga
- **Surname:** Spala
- **Module:** WEDE5020
- **Chosen organisation type:** Small Business (bakery)

## Project Overview
Sweet Crumb Artisan Bakery is a small, hypothetical Cape Town bakery selling
sourdough bread, pastries and celebration cakes. This repository contains the
website built for Sweet Crumb across the three parts of the WEDE5020 Portfolio
of Evidence (PoE): the foundational HTML structure (Part 1), CSS styling
(Part 2), and JavaScript functionality (Part 3).

The goal of the website is to give the bakery an online presence that:
1. introduces new customers to the bakery and its story,
2. shows the current menu and prices so customers know what to expect,
3. allows customers to enquire about custom cakes, catering and wholesale
   orders, and
4. gives customers the bakery's two locations, hours and general contact
   details.

## Website Goals and Objectives
- Present a warm, trustworthy first impression that reflects a small,
  hand-made bakery (not a large chain).
- Make the current menu and prices easy to find and scan.
- Convert visitors into custom-order enquiries (cakes, catering, wholesale).
- Provide clear, accurate location, hours and contact information for both
  the Kloof Street shopfront and the Kalk Bay weekend kiosk.
- Be usable on both desktop and mobile devices, since most local customers
  will browse on a phone.

## Key Features and Functionality (Part 1 + Part 2 scope)
- Semantic, standards-compliant HTML5 structure across 5 pages.
- A consistent header with a fully working navigation system (CSS-only
  responsive/mobile menu via a checkbox toggle — no JavaScript required for
  this yet, in line with Part 1's focus on HTML).
- A menu page listing bread, pastries and cakes with prices.
- A custom-order enquiry form (name, contact details, enquiry type, date,
  message) with proper `<label>`/`<input>` association and HTML5 validation
  attributes (`required`, `type="email"`, etc.).
- A contact page with two physical locations, each with an embedded map.
- A general contact form.
- An organised file/folder structure (`css/`, `js/`, `images/`).
- **(Part 2)** A single external stylesheet (`css/style.css`) linked from
  every page, built on CSS custom properties (design tokens) for colour and
  type, with a base/reset layer, decorative and typographic styling, and
  `:hover`/`:focus-visible`/`:active` states on every interactive element.
- **(Part 2)** Layout built with CSS Grid (hero, footer, team grid, locations)
  and Flexbox (header, menu rows, form rows), rather than fixed positioning.
- **(Part 2)** Fully responsive across desktop, tablet and mobile using
  media-query breakpoints, relative units (`rem`, `em`, `%`, `ch`, `vw`,
  `clamp()`), and two real responsive-image techniques (`<picture>` with
  art-direction, and plain `<img srcset sizes>`) — see *Responsive Design*
  below.

> Form submission logic and other dynamic/interactive behaviour (inline
> validation feedback, an image gallery/lightbox, etc.) are intentionally
> **not** implemented yet — these belong to Part 3 (JavaScript functionality)
> of the PoE.

## Timeline and Milestones (Part 1)
| Milestone                                   | Target date |
|---------------------------------------------|-------------|
| Target organisation chosen & proposal drafted | Week 1     |
| Proposal submitted for lecturer approval      | Week 1     |
| Content research and sourcing completed       | Week 2     |
| Sitemap and file/folder structure finalised    | Week 2     |
| HTML pages built and internally linked         | Week 3     |
| Cross-browser/device testing and clean-up       | Week 3     |
| Part 1 pushed to GitHub and submitted           | Week 3     |

*(Adjust the above dates to match your actual module submission calendar.)*

## Part 1 Details
Part 1 — Building the Foundation covers project initiation and planning:
choosing a target organisation, writing a project proposal, researching and
sourcing content, planning the sitemap and file structure, and building the
initial HTML structure and content for all five pages. See
`docs/website-project-proposal.docx` (submitted separately, as required) for
the full written proposal, including the second, non-selected organisation
proposal presented for comparison.

### Low-fidelity wireframes
Lecturer feedback on the original Part 1 submission noted that low-fidelity
wireframes could not be verified from the submitted material (0/2). Five
wireframes, one per page, have now been added to `docs/wireframes/` and are
also included as an appendix in the updated `Website_Project_Proposal.docx`.
They are deliberately greyscale, box-and-line diagrams (no colour, real type
or imagery) showing each page's layout and information hierarchy, matching
what was actually built:

| Page | Wireframe |
|------|-----------|
| Home | ![Home wireframe](docs/wireframes/wireframe-home.png) |
| About Us | ![About wireframe](docs/wireframes/wireframe-about.png) |
| Our Menu | ![Menu wireframe](docs/wireframes/wireframe-menu.png) |
| Enquire | ![Enquire wireframe](docs/wireframes/wireframe-enquire.png) |
| Contact | ![Contact wireframe](docs/wireframes/wireframe-contact.png) |

## Part 2 Details — Designing the Visuals: CSS Styling and Responsive Design

### 1. Working through feedback from Part 1
Lecturer feedback on Part 1 was positive overall (strong proposal
documentation, strong HTML/semantic structure, strong forms and comments,
comprehensive README) and identified two specific gaps, both of which have
now been corrected:

1. **Low-fidelity wireframes could not be verified (0/2).** Five wireframes
   (one per page) have been created and added to `docs/wireframes/`, linked
   above under *Part 1 Details*, and appended to
   `Website_Project_Proposal.docx`.
2. **Content research was strong but didn't show explicit evidence of how
   individual sources informed the final content.** The content-research
   deliverable (`content-research.zip`, submitted separately per section
   7.2) has been updated with an explicit source → decision → "where used
   on the site" traceability table in `text/page-content-notes.md`, so each
   research input can be traced through to the specific content decision it
   produced.

No other corrections were requested, so the rest of the Part 1 HTML,
structure and content were left as submitted.

### 2. CSS styling approach
- **External stylesheet:** a single `css/style.css` is linked from the
  `<head>` of every page (see `2.1` in the brief) using a consistent
  filename and path across all five pages.
- **Base style / reset:** `:root` design tokens (colour palette, two font
  families) plus a small reset (`* { box-sizing: border-box }`, margin/link
  defaults) keep styling consistent across browsers (`2.2`).
- **Typography:** `font-family`, `font-size` (fluid, via `clamp()` for
  headings), `font-weight`, `line-height` and `letter-spacing` are set from
  the design tokens so type stays consistent across the whole site (`2.3`).
- **Layout:** CSS Grid is used for the hero, footer, team grid and the two
  contact-page locations; Flexbox is used for the header/nav, buttons row,
  and menu-list rows (`2.4`).
- **Visual styles & interaction states:** `color`, `background-color`,
  `border` and subtle shadows/dividers style elements, and every interactive
  element (links, nav items, buttons) has explicit `:hover`, `:focus-visible`
  and `:active` states (`2.5`).

### 3. Responsive design
**Breakpoints used** (documented at the top of `style.css`):

| Tier    | Breakpoint     | What changes |
|---------|----------------|--------------|
| Desktop | > 1024px (default, no query) | Full multi-column layout |
| Tablet  | ≤ 1024px       | `.container` padding and hero/section spacing tighten; layout stays multi-column |
| Mobile  | ≤ 780px        | Hero, locations, story and team grids collapse to one column |
| Small   | ≤ 600–720px    | Nav collapses to a toggle menu; menu list and form rows stack fully; buttons become full-width |

- **Relative units:** `rem`/`em` for spacing and type, `%` for element widths
  (e.g. buttons go `width: 100%` on small screens instead of a fixed pixel
  width — see `.hero-actions .btn` in `style.css`), and `ch`/`vw`/`clamp()`
  for fluid text measure and sizing.
- **Responsive images:** two real techniques are used, not just CSS
  `max-width: 100%`:
  - `about.html` uses a `<picture>` element with a `<source media="(max-width:
    600px)">` to serve a **different, tighter, taller crop** of the shopfront
    illustration on small screens (true art direction), falling back to a
    wide desktop crop with a full `srcset`/`sizes` set for the rest.
  - `index.html` uses a plain `<img srcset sizes>` (no `<picture>`) next to
    the pull-quote, letting the browser pick the best resolution of the same
    crop for its rendered width.
  - All image files are original illustrations generated for this project
    (see `images/`), avoiding any copyright/licensing concerns.
- **Testing:** every page was checked with browser developer tools at
  desktop (1280px), tablet (800px) and mobile (390px) widths.

### Screenshot evidence (desktop / tablet / mobile)
All screenshots below are stored in `docs/screenshots/`.

**Home page**
![Home — desktop](docs/screenshots/index-desktop-1280.png)
![Home — tablet](docs/screenshots/index-tablet-800.png)
![Home — mobile](docs/screenshots/index-mobile-390.png)

**About page** (shows the `<picture>` art-directed image switching crop)
![About — desktop](docs/screenshots/about-desktop-1280.png)
![About — mobile](docs/screenshots/about-mobile-390.png)

**Our Menu page — mobile** (menu-list breakpoint)
![Menu — mobile](docs/screenshots/products-mobile-390.png)

**Contact page** (two-location grid + form breakpoints)
![Contact — tablet](docs/screenshots/contact-tablet-800.png)
![Contact — mobile](docs/screenshots/contact-mobile-390.png)

## Sitemap

```
                        Home (index.html)
                              |
   -----------------------------------------------------------
   |               |                  |                     |
About Us       Our Menu           Enquire               Contact
(about.html)  (products.html)   (enquiry.html)        (contact.html)
   |               |                  |                     |
 Our story      Bread              Custom order        Kloof Street
 Our values     Pastries & cakes   enquiry form        Kalk Bay kiosk
 Meet the team  Prices             (name, contact,      General contact
 Opening hours                      enquiry type,        form
                                    date, message)
```

All five pages share the same header (logo + navigation) and footer
(location, hours, contact) for a consistent navigation experience.

## File and Folder Structure
```
sweet-crumb-bakery/
├── index.html          Home page
├── about.html          About Us page
├── products.html       Menu / products page
├── enquiry.html        Custom order enquiry form
├── contact.html        Locations, maps and general contact form
├── css/
│   └── style.css       Single project stylesheet
├── js/
│   └── script.js       Reserved for Part 3 interactivity
├── images/             Original shopfront illustrations, exported at
│                        multiple widths for srcset/picture (Part 2)
├── docs/
│   └── screenshots/    Desktop/tablet/mobile screenshot evidence (Part 2)
└── README.md           This file
```

## Changelog
- **v0.1 (Part 1):** Initial project setup; five HTML pages built with
  semantic structure, working navigation, menu content, enquiry form and
  contact/locations page; base stylesheet added for readability during
  development; README created.
- **v0.2 (Part 2 — feedback pass):** Actioned lecturer feedback on Part 1.
  (a) Wireframes: created five low-fidelity, greyscale wireframes (one per
  page — Home, About Us, Our Menu, Enquire, Contact), showing layout and
  information hierarchy only (no colour/type/imagery), matching the
  structure actually built; added to `docs/wireframes/` and appended to
  `Website_Project_Proposal.docx` as Appendix A. This corrects the 0/2
  wireframe gap noted in feedback. (b) Content research traceability: added
  an explicit source → decision → "where used" table to
  `content-research/text/page-content-notes.md` (see the separately
  submitted `content-research.zip`) so each research input is traceable to
  the specific content decision it produced, addressing the feedback that
  this evidence was not explicit enough. No other Part 1 corrections were
  requested in the feedback received.
- **v0.3 (Part 2 — CSS styling):** Documented breakpoint tiers at the top of
  `style.css`; added an explicit tablet-tier media query (`≤1024px`)
  tightening spacing without collapsing the layout; added `:active` states
  to buttons and nav links (previously only `:hover`/`:focus-visible`);
  added a `%`-based full-width button rule for the smallest screens as a
  second relative-unit responsive technique alongside `rem`/`em`.
- **v0.4 (Part 2 — responsive images):** Generated original shopfront
  illustration artwork and exported it at four widths (480/800/1200/1600px)
  for `srcset`, plus a separate tighter portrait crop at two widths for
  mobile art direction; added a `<picture>` element with a `max-width:600px`
  `<source>` to `about.html`, and a plain `<img srcset sizes>` to
  `index.html`; added corresponding layout CSS (`.story-split`,
  `.storefront-figure`).
- **v0.5 (Part 2 — testing & evidence):** Tested all five pages at desktop
  (1280px), tablet (800px) and mobile (390px) widths using browser developer
  tools; saved screenshot evidence to `docs/screenshots/` and linked it in
  this README.

- **v0.6 (Part 2 — self-check):** Brief explicitly names `box-shadow` as a
  visual-style property (2.5) alongside `color`/`background-color`/`border`;
  it wasn't used anywhere in the original Part 2 pass. Added a subtle
  `box-shadow` to `.location-card` (contact page) and a slightly stronger
  one to `.btn:hover` (a lift effect tied to the hover state), so all four
  named properties are now genuinely present.
- Fraunces and Work Sans web fonts served via Google Fonts:
  https://fonts.google.com/
- Map embeds via OpenStreetMap: https://www.openstreetmap.org/
- General HTML5 semantic element guidance: Mozilla Developer Network (MDN),
  "HTML elements reference," https://developer.mozilla.org/en-US/docs/Web/HTML/Element
- CSS Grid layout guidance: Mozilla Developer Network (MDN), "CSS Grid
  Layout," https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout
- Flexbox layout guidance: Mozilla Developer Network (MDN), "CSS Flexible
  Box Layout," https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout
- Responsive images guidance (`srcset`, `sizes`, `<picture>`): Mozilla
  Developer Network (MDN), "Responsive images,"
  https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive_images
- Media queries / breakpoints guidance: Mozilla Developer Network (MDN),
  "Using media queries," https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries/Using_media_queries
- The Independent Institute of Education (IIE), *WEDE5020 Module Guide*, 2026.

*Note: please verify the above reference details/URLs before final
submission — the MDN links added for Part 2 are from general knowledge of
MDN's documentation structure rather than a live search, so double-check
each URL still resolves to the right page before you submit.*
