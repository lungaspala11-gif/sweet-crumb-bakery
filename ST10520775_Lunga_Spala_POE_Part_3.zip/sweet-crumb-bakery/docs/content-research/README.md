# Content Research and Sourcing — Sweet Crumb Artisan Bakery

**Student Number:** ST10520775
**Name:** Lunga Spala
**Module:** WEDE5020 — Part 1

This folder is the deliverable for section 7.2 ("Content Research and
Sourcing") of the Part 1 brief. It contains all relevant researched and
created content used to build the Sweet Crumb Artisan Bakery website.

- **images/** — Reserved for sourced/licensed image assets. For Part 1, no
  external images were used (see `documents/image-sourcing-log.md` for the
  reasoning); all visuals were built as original SVG code directly in the
  website's HTML files.
- **documents/** — `image-sourcing-log.md` records the decisions made about
  every visual asset used (or deliberately not used) on the site, including
  licensing notes.
- **text/** — `page-content-notes.md` documents where the written content
  for each page came from and how it was developed/researched.

See the main website repository's `README.md` for the full sitemap, file
structure, and reference list.
