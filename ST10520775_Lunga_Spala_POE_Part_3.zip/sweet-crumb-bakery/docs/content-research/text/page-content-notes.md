# Content Research & Sourcing Notes — Sweet Crumb Artisan Bakery

**Student:** Lunga Spala (ST10520775) — WEDE5020, Part 1

Since Sweet Crumb Artisan Bakery is a hypothetical small business (as
permitted by the assignment brief), there is no existing organisational
website or social media to draw content from. All page content below was
therefore **originally written** for this project, grounded in realistic
research into how small Cape Town bakeries typically describe themselves,
price their products, and structure their opening hours. This satisfies the
brief's "Original Content" sourcing category.

## Home page (index.html)
- Tagline: "Baked slow. Sold local." — written to capture the brand's slow
  fermentation process and local-sourcing focus.
- "What we bake" summaries for bread, pastries and cakes — written to be
  scannable in one glance.
- Founder pull-quote — original, written in the voice of the (fictional)
  founder, Maria Ndlovu.
- "This week's specials" — three items with realistic Cape Town bakery
  pricing (researched against typical artisan bakery price points in Rand).

## About Us page (about.html)
- Founding story (2019, Ferrandi Paris training, Kloof Street market stall
  origin) — original backstory, written to be plausible and specific rather
  than generic.
- "What we believe in" — three value statements (slow fermentation, local
  sourcing, small batches) reflecting real artisan-bakery practices.
- Team bios for Maria Ndlovu, Sipho Dlamini and Aisha Petersen — original.
- Opening hours table — realistic hours for a small bakery (closed Sun/Mon,
  half-day Saturday, plus weekend-only kiosk hours).

## Our Menu page (products.html)
- Three menu categories (Bread; Pastries & Viennoiserie; Cakes & Custom
  Orders), each with 3–4 items, short descriptors and Rand pricing.
- Pricing was sanity-checked against realistic 2025/2026 Cape Town artisan
  bakery price ranges (loaves roughly R30–R60, pastries roughly R25–R35,
  whole cakes roughly R350–R450) so the menu reads as credible rather than
  arbitrary.

## Enquire page (enquiry.html)
- Introductory copy explaining what the form is for (custom cakes, catering,
  wholesale).
- Form field list (contact details, enquiry type, event/delivery date,
  quantity, message) based on common fields used by real bakery/catering
  enquiry forms researched for this project.

## Contact page (contact.html)
- Two location descriptions (Kloof Street shopfront; Kalk Bay Harbour Market
  weekend kiosk) with realistic Cape Town addresses and hours.
- General contact form for enquiries that don't fit the custom-order form.

## Sources consulted while researching tone, structure and pricing
(General background research only — no text or images were copied directly
from these sources; see `README.md` for the full reference list.)
- Publicly available Cape Town bakery and café websites and social media
  pages, consulted only to understand typical page structure, tone and menu
  pricing conventions for this type of business (not quoted or copied).
- The WEDE5020 module guide's Part 1 requirements, used to confirm the
  required page set and content fields.
