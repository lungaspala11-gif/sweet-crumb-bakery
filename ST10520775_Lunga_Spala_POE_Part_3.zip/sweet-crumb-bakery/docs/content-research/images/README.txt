No external images were sourced for Part 1 — see ../documents/image-sourcing-log.md.
This folder is kept in place for any licensed/sourced images added in later parts.
