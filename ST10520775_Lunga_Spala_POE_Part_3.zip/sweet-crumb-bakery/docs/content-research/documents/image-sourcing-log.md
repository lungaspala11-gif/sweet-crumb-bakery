# Image & Asset Sourcing Log — Sweet Crumb Artisan Bakery

**Student:** Lunga Spala (ST10520775) — WEDE5020, Part 1

## Decision
Sweet Crumb Artisan Bakery is a hypothetical business created for this
assignment, so no genuine, licensable product photography exists for it, and
using unrelated stock photography of other brands' bread/pastries risked
looking inconsistent and would raise the same licensing questions the
referencing rubric warns against ("ensure they are properly licensed or in
the public domain").

To avoid this issue entirely, all visual assets for Part 1 (the hero
illustration and the three "What we bake" icons on the home page) were
**created from scratch as original, hand-coded SVG line-art** directly in the
project files, rather than sourced from an external image library. Because
these are original work, no external image licence or attribution is
required for them.

| Asset                          | Source                          | Licence needed? |
|---------------------------------|----------------------------------|------------------|
| Hero bread illustration (index.html) | Original SVG, hand-coded    | No — original work |
| Bread / pastry / cake icons (index.html) | Original SVG, hand-coded | No — original work |
| Team avatar initials (about.html) | Original CSS/HTML, no image file | No — original work |
| Location maps (contact.html)   | OpenStreetMap embed (openstreetmap.org) | No — © OpenStreetMap contributors, ODbL, embed permitted for non-commercial/educational use |
| Fonts: Fraunces, Work Sans     | Google Fonts (fonts.google.com) | No — both are open-source, free for commercial and personal use (SIL Open Font License) |

## Follow-up for Part 2/3
If real product photography becomes available or is required later in the
PoE, it must be sourced from a royalty-free/Creative-Commons library (e.g.
Unsplash, Pexels) or taken originally, and the exact source URL and licence
must be added to this log and to the reference list in `README.md`.
