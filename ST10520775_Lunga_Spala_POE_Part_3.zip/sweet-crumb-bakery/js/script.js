/* =====================================================
   Sweet Crumb Artisan Bakery — script.js
   Student: Lunga Spala (ST10520775) — WEDE5020, Part 3

   Sections
     1. Menu data (single source of truth)
     2. Scroll-reveal animation
     3. Accordion (FAQ)
     4. Gallery lightbox
     5. Dynamic menu: render, search, filter, sort
     6. Interactive maps (Leaflet)
     7. Form validation helpers
     8. Enquiry form (validation + AJAX + quote)
     9. Contact form (validation + compiled email)
   ===================================================== */
(function () {
  "use strict";

  const RECIPIENT = "hello@sweetcrumbbakery.co.za";
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const rand = (n) => "R" + n.toLocaleString("en-ZA");

  /* ---------- 1. Menu data ---------- */
  const CATEGORIES = { bread: "Bread", pastries: "Pastries & Viennoiserie", cakes: "Cakes & Custom Orders" };
  const MENU = [
    { name: "Sourdough Country Loaf", desc: "24-hour fermented, crisp crust, open crumb", price: 55, cat: "bread" },
    { name: "Whole Wheat Seed Loaf", desc: "Sunflower, linseed and sesame", price: 48, cat: "bread" },
    { name: "Baguette", desc: "Classic French-style, baked twice daily", price: 32, cat: "bread" },
    { name: "Roosterkoek Loaf", desc: "Weekend special — braai-style flatbread", price: 45, cat: "bread", special: true },
    { name: "Butter Croissant", desc: "Laminated over three days, baked to order", price: 28, cat: "pastries" },
    { name: "Pain au Chocolat", desc: "Dark chocolate batons, flaky lamination", price: 32, cat: "pastries" },
    { name: "Cinnamon Morning Bun", desc: "Croissant dough, cinnamon sugar, orange glaze", price: 30, cat: "pastries" },
    { name: "Fig & Honey Danish", desc: "Local fig jam and honey glaze", price: 34, cat: "pastries", special: true },
    { name: "Classic Vanilla Sponge (whole)", desc: "Serves 8–10, vanilla buttercream", price: 380, cat: "cakes" },
    { name: "Chocolate Fudge Cake (whole)", desc: "Serves 8–10, dark chocolate ganache", price: 420, cat: "cakes" },
    { name: "Rooibos & Orange Loaf Cake", desc: "Serves 6–8", price: 150, cat: "cakes", special: true },
    { name: "Custom Celebration Cake", desc: "Weddings, birthdays & events — design and flavour to order", price: 650, cat: "cakes", from: true }
  ];

  /* Build a menu <li> using DOM methods (textContent => no injection risk) */
  function menuItem(item) {
    const li = document.createElement("li");
    [["item-name", item.name], ["item-desc", item.desc], ["item-leader", ""],
      ["item-price", (item.from ? "From " : "") + rand(item.price)]].forEach(([cls, text]) => {
      const s = document.createElement("span");
      s.className = cls;
      s.textContent = text;
      li.appendChild(s);
    });
    return li;
  }

  /* ---------- 2. Scroll-reveal animation ---------- */
  function initReveal() {
    const targets = $$(".bake-item, .team-card, .location-card, .gallery-item, .accordion-item, .section-head");
    if (!("IntersectionObserver" in window) || reduceMotion) return;
    targets.forEach((el) => el.classList.add("reveal"));
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) { e.target.classList.add("is-visible"); io.unobserve(e.target); }
      });
    }, { threshold: 0.12 });
    targets.forEach((el) => io.observe(el));
  }

  /* ---------- 3. Accordion ---------- */
  function initAccordion() {
    $$(".accordion").forEach((acc) => {
      const buttons = $$(".accordion-trigger", acc);
      buttons.forEach((btn) => {
        btn.addEventListener("click", () => {
          const wasOpen = btn.getAttribute("aria-expanded") === "true";
          buttons.forEach((b) => {
            b.setAttribute("aria-expanded", "false");
            document.getElementById(b.getAttribute("aria-controls")).style.maxHeight = null;
          });
          if (!wasOpen) {
            const panel = document.getElementById(btn.getAttribute("aria-controls"));
            btn.setAttribute("aria-expanded", "true");
            panel.style.maxHeight = panel.scrollHeight + "px";
          }
        });
      });
    });
  }

  /* ---------- 4. Gallery lightbox ---------- */
  function initLightbox() {
    const links = $$(".gallery-item a");
    if (!links.length) return;
    const box = document.createElement("div");
    box.className = "lightbox";
    box.setAttribute("role", "dialog");
    box.setAttribute("aria-modal", "true");
    box.setAttribute("aria-label", "Image viewer");
    box.hidden = true;
    box.innerHTML =
      '<button class="lb-close" aria-label="Close image viewer">&times;</button>' +
      '<button class="lb-prev" aria-label="Previous image">&#10094;</button>' +
      '<figure><img alt=""><figcaption></figcaption></figure>' +
      '<button class="lb-next" aria-label="Next image">&#10095;</button>';
    document.body.appendChild(box);
    const img = $("img", box), cap = $("figcaption", box);
    let index = 0, lastFocus = null;

    function show(i) {
      index = (i + links.length) % links.length;
      const a = links[index], thumb = $("img", a);
      img.src = a.getAttribute("href");
      img.alt = thumb.alt;
      cap.textContent = thumb.alt + " (" + (index + 1) + " of " + links.length + ")";
    }
    function open(i) { lastFocus = document.activeElement; show(i); box.hidden = false; document.body.classList.add("no-scroll"); $(".lb-close", box).focus(); }
    function close() { box.hidden = true; document.body.classList.remove("no-scroll"); if (lastFocus) lastFocus.focus(); }

    links.forEach((a, i) => a.addEventListener("click", (e) => { e.preventDefault(); open(i); }));
    $(".lb-close", box).addEventListener("click", close);
    $(".lb-prev", box).addEventListener("click", () => show(index - 1));
    $(".lb-next", box).addEventListener("click", () => show(index + 1));
    box.addEventListener("click", (e) => { if (e.target === box) close(); });
    document.addEventListener("keydown", (e) => {
      if (box.hidden) return;
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") show(index - 1);
      if (e.key === "ArrowRight") show(index + 1);
    });
  }

  /* ---------- 5. Dynamic menu ---------- */
  function initSpecials() {
    const list = $("#specials-list");
    if (list) list.replaceChildren(...MENU.filter((m) => m.special).map(menuItem));
  }

  function initMenu() {
    const root = $("#menu-root");
    if (!root) return;
    const tools = $("#menu-tools"), search = $("#menu-search"), cat = $("#menu-category"),
      sort = $("#menu-sort"), count = $("#menu-count");
    tools.hidden = false;

    function render() {
      const q = search.value.trim().toLowerCase();
      let items = MENU.filter((m) =>
        (cat.value === "all" || m.cat === cat.value) &&
        (!q || (m.name + " " + m.desc).toLowerCase().includes(q)));
      const by = {
        "price-asc": (a, b) => a.price - b.price,
        "price-desc": (a, b) => b.price - a.price,
        "name-asc": (a, b) => a.name.localeCompare(b.name)
      }[sort.value];
      if (by) items = items.slice().sort(by);

      root.replaceChildren();
      if (!items.length) {
        const p = document.createElement("p");
        p.className = "menu-empty";
        p.textContent = "No items match “" + search.value.trim() + "”. Try another word, or ask us about a custom order.";
        root.appendChild(p);
      } else if (sort.value === "default") {
        Object.keys(CATEGORIES).forEach((key) => {
          const group = items.filter((m) => m.cat === key);
          if (!group.length) return;
          const wrap = document.createElement("div");
          wrap.className = "menu-category";
          wrap.id = key; // keeps the #bread / #pastries / #cakes links from the home page working
          const h = document.createElement("h2");
          h.textContent = CATEGORIES[key];
          const ul = document.createElement("ul");
          ul.className = "menu-list";
          group.forEach((m) => ul.appendChild(menuItem(m)));
          wrap.append(h, ul);
          root.appendChild(wrap);
        });
      } else {
        const ul = document.createElement("ul");
        ul.className = "menu-list";
        items.forEach((m) => ul.appendChild(menuItem(m)));
        root.appendChild(ul);
      }
      count.textContent = items.length + (items.length === 1 ? " item" : " items") + " shown";
    }
    [search, cat, sort].forEach((el) => el.addEventListener("input", render));
    $("#menu-reset").addEventListener("click", () => { search.value = ""; cat.value = "all"; sort.value = "default"; render(); search.focus(); });
    render();
    if (location.hash) { const t = document.getElementById(location.hash.slice(1)); if (t) t.scrollIntoView(); }
  }

  /* ---------- 6. Interactive maps ---------- */
  function initMaps() {
    const holders = $$(".map-canvas");
    if (!holders.length || typeof L === "undefined") return;
    holders.forEach((el) => {
      const lat = parseFloat(el.dataset.lat), lng = parseFloat(el.dataset.lng);
      const map = L.map(el, { scrollWheelZoom: false }).setView([lat, lng], 16);
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);
      L.marker([lat, lng]).addTo(map).bindPopup("<strong>" + el.dataset.title + "</strong><br>" + el.dataset.hours);
    });
  }

  /* ---------- 7. Form validation helpers ---------- */
  const RULES = {
    name: (v) => /^[A-Za-zÀ-ÿ' -]{2,60}$/.test(v) || "Enter your name using letters only (2–60 characters).",
    email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) || "Enter a valid email address, e.g. name@example.com.",
    phone: (v) => v === "" || /^(\+27|0)[1-9]\d{8}$/.test(v.replace(/[\s-]/g, "")) || "Enter a South African number, e.g. 021 000 1234 or +27 82 123 4567.",
    select: (v) => v !== "" || "Please choose an option.",
    message: (v) => (v.length >= 10 && v.length <= 1000) || "Your message must be between 10 and 1000 characters.",
    subject: (v) => v.length <= 80 || "Keep the subject under 80 characters."
  };

  function setError(field, msg) {
    let box = field.parentElement.querySelector(".field-error");
    if (!box) {
      box = document.createElement("span");
      box.className = "field-error";
      box.id = field.id + "-error";
      box.setAttribute("role", "alert");
      field.parentElement.appendChild(box);
      field.setAttribute("aria-describedby", box.id);
    }
    box.textContent = msg || "";
    field.classList.toggle("is-invalid", !!msg);
    field.setAttribute("aria-invalid", msg ? "true" : "false");
    return !msg;
  }
  function check([field, rule]) {
    const v = field.value.trim();
    if (field.required && v === "") return setError(field, "This field is required.");
    const res = rule(v);
    return setError(field, res === true ? "" : res);
  }
  function runChecks(checks) {
    let firstBad = null;
    checks.forEach((c) => { if (!check(c) && !firstBad) firstBad = c[0]; });
    if (firstBad) firstBad.focus();
    return !firstBad;
  }
  function liveValidate(checks) {
    checks.forEach((c) => {
      c[0].addEventListener("blur", () => check(c));
      c[0].addEventListener("input", () => { if (c[0].classList.contains("is-invalid")) check(c); });
    });
  }

  /* ---------- 8. Enquiry form ---------- */
  const NOTICE = { "custom-cake": 7, catering: 14, wholesale: 5, other: 2 };

  function buildQuote(type, qty, dateStr) {
    const out = [];
    if (type === "custom-cake") {
      const extra = qty > 10 ? (qty - 10) * 35 : 0;
      out.push("Estimated cost: from " + rand(650 + extra) + " (base price R650" + (extra ? " + R35 per guest above 10" : "") + ").");
      out.push("Lead time: custom cakes need at least 7 days’ notice.");
    } else if (type === "catering") {
      const guests = Math.max(qty || 10, 10);
      out.push("Estimated cost: about " + rand(guests * 85) + " for " + guests + " guests (R85 per guest, minimum 10 guests).");
      out.push("Lead time: catering needs at least 14 days’ notice.");
    } else if (type === "wholesale") {
      out.push("Estimated cost: " + (qty ? rand(qty * 38) + " per delivery for " + qty + " loaves" : "R38 per loaf") + " (wholesale rate).");
      out.push("Lead time: new wholesale accounts start with 5 working days’ notice.");
    } else {
      out.push("We’ll review your request and reply with pricing and availability.");
    }
    if (dateStr) {
      const d = new Date(dateStr + "T00:00:00");
      const days = Math.ceil((d - new Date().setHours(0, 0, 0, 0)) / 86400000);
      if (d.getDay() === 0 || d.getDay() === 1) out.push("Availability: we’re closed on Sundays and Mondays — the nearest pick-up day is Tuesday.");
      else if (days < NOTICE[type]) out.push("Availability: " + dateStr + " is inside our " + NOTICE[type] + "-day notice period, so it is subject to confirmation.");
      else out.push("Availability: " + dateStr + " is currently open — we’ll confirm when we reply.");
    } else {
      out.push("Availability: add a date and we’ll check it for you.");
    }
    return out;
  }

  function initEnquiry() {
    const form = $("#enquiry-form");
    if (!form) return;
    const f = (id) => $("#" + id, form);
    const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().split("T")[0];
    f("event-date").min = today;
    const checks = [
      [f("name"), RULES.name], [f("email"), RULES.email], [f("phone"), RULES.phone],
      [f("enquiry-type"), RULES.select],
      [f("event-date"), (v) => v === "" || v >= today || "Choose today’s date or a future date."],
      [f("guests"), (v) => v === "" || (/^\d+$/.test(v) && +v >= 1 && +v <= 500) || "Enter a whole number between 1 and 500."],
      [f("message"), RULES.message]
    ];
    liveValidate(checks);

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!runChecks(checks)) return;
      const btn = $("button[type=submit]", form), panel = $("#enquiry-response");
      const data = Object.fromEntries(new FormData(form).entries());
      btn.disabled = true; btn.textContent = "Sending…";
      panel.hidden = false; panel.className = "form-response"; panel.textContent = "Sending your enquiry…";
      try {
        // AJAX: submit asynchronously to the URL in the form's action attribute
        const res = await fetch(form.action, {
          method: "POST",
          headers: { "Content-Type": "application/json; charset=UTF-8" },
          body: JSON.stringify(data)
        });
        if (!res.ok) throw new Error("server responded " + res.status);
        const ref = "SC-" + String(Date.now()).slice(-6);
        const lines = buildQuote(data["enquiry-type"], parseInt(data.guests, 10) || 0, data["event-date"]);
        panel.className = "form-response is-success";
        panel.replaceChildren();
        const h = document.createElement("h3");
        h.textContent = "Thank you, " + data.name.split(" ")[0] + " — enquiry " + ref + " received";
        const ul = document.createElement("ul");
        lines.forEach((t) => { const li = document.createElement("li"); li.textContent = t; ul.appendChild(li); });
        const note = document.createElement("p");
        note.textContent = "These figures are estimates. We’ll email " + data.email + " within two working days to confirm.";
        panel.append(h, ul, note);
        form.reset();
      } catch (err) {
        panel.className = "form-response is-error";
        panel.textContent = "Sorry, we couldn’t send your enquiry (" + err.message + "). Please try again, or email " + RECIPIENT + ".";
      } finally {
        btn.disabled = false; btn.textContent = "Send enquiry";
        panel.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "nearest" });
      }
    });
  }

  /* ---------- 9. Contact form ---------- */
  function initContact() {
    const form = $("#contact-form");
    if (!form) return;
    const f = (id) => $("#" + id, form);
    const checks = [
      [f("c-name"), RULES.name], [f("c-email"), RULES.email], [f("c-phone"), RULES.phone],
      [f("c-type"), RULES.select], [f("c-subject"), RULES.subject], [f("c-message"), RULES.message]
    ];
    liveValidate(checks);
    f("c-message").addEventListener("input", (e) => { $("#c-count").textContent = e.target.value.length + " / 1000"; });

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      if (!runChecks(checks)) return;
      const v = (id) => f(id).value.trim();
      const type = f("c-type").selectedOptions[0].textContent;
      const subject = "[" + type + "] " + (v("c-subject") || "Message from website");
      const body = "Name: " + v("c-name") + "\nEmail: " + v("c-email") + "\nPhone: " + (v("c-phone") || "not provided") +
        "\nType of message: " + type + "\n\n" + v("c-message");
      // compile into an email addressed to the recipient stated in the code (RECIPIENT)
      const href = "mailto:" + RECIPIENT + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
      const panel = $("#contact-response");
      panel.hidden = false; panel.className = "form-response is-success";
      panel.replaceChildren();
      const h = document.createElement("h3"); h.textContent = "Your email is ready to send";
      const pre = document.createElement("pre");
      pre.textContent = "To: " + RECIPIENT + "\nSubject: " + subject + "\n\n" + body;
      const a = document.createElement("a");
      a.className = "btn"; a.href = href; a.textContent = "Send email";
      panel.append(h, pre, a);
      panel.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "nearest" });
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    initSpecials(); initMenu(); initAccordion(); initLightbox();
    initMaps(); initEnquiry(); initContact(); initReveal();
  });
})();
